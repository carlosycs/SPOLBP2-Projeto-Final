package com.ifsp.projeto3bim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto3bimApplication {

	public static void main(String[] args) {
		SpringApplication.run(Projeto3bimApplication.class, args);
	}

}
